/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import model.Model_login;
/**
 *
 * @author Novita
 */
public interface Service_Login {
    void prosesLogin (Model_login mod_login);
}
